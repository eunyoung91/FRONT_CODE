// -----------------------------------------------------------------------------
// rMate Chart H5 License Key 
//
// Product Name : rMate Chart for HTML5 v4.0
// License Type : Standard license
// Product No : 410F-2F9C-FE95-718Z
// Customer : ������(eduwill)
// Authenticated server Info : the number of authenticated server = 2, server's IP = 112.175.57.139, 112.175.57.140, server's Domain = dokhan.eduwill.net
// Expiration date : 2017/01/22
//
var rMateChartH5License = "1e2f8426f7d214bfb279854aa81a606418b9eb3397b4c9b42d2914406797e65b:6600390b63372f31303031322f3a3245322020744c653a6e342e316c306c46692d77327546643965432e2d6e46614568396b356f2d64372c313038345a31202e503742353a2e483544374f31202e4c3256313a31322c2e3930332031502e56373a35432e35352d375331542e2d3234312e31302c203445314c323a2e66372035432e3a3532373031312e363231313131323a3248";
// -----------------------------------------------------------------------------
