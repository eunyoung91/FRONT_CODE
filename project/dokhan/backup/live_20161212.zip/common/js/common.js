/**========================================================================================================
* 용  도 : ajaxUtil Util
* 작성자 : 안치성 정예지 수정  치성 또 수정
* 이클립스 짱짱짱!!!
* 작성일 : 2016-10-17
*========================================================================================================*/


// 여기 추가했어요 by 안치성
var AjaxUtil = (function(){
	
	function AjaxUtil_(){
		
	}
	
	/**========================================================================================================
	* 용  도 : Ajax for Json
	* 작성자 : 안치성
	*========================================================================================================*/
	AjaxUtil_.prototype.commonAjax = function(callUrl){
		$.ajax({
			type:"GET",
			async:true,			// true-비동기, false-동기
			url:callUrl,
			crossDomain:false,
			dataType:"json",
			timeout:5000,
			cache:false,
			data:"",
			success:function(data, textStatus, jqXHR){
				try{
					ajaxResult(data);
				}catch(e){}
			},
			error:function(xhr, msg, e){
				try{
					ajaxFail();
				}catch(e){}
			}
		});
	};
	
	
	/**========================================================================================================
	* 용  도 : Ajax for Json
	* 작성자 : 안치성
	*========================================================================================================*/
	AjaxUtil_.prototype.commonAjax2 = function(callUrl, gubun){
		$.ajax({
			type:"GET",
			async:true,			// true-비동기, false-동기
			url:callUrl,
			crossDomain:false,
			dataType:"json",
			timeout:5000,
			cache:false,
			data:"",
			success:function(data, textStatus, jqXHR){
				try{
					ajaxResult2(data, gubun);
				}catch(e){}
			},
			error:function(xhr, msg, e){
				try{
					ajaxFail2();
				}catch(e){}
			}
		});
	};
	
	
	return AjaxUtil_;
})();

// 현재콘텐츠의 높이를 기준으로 부모창 Frame 높이 조절
function parentFrameAutoReSize(contentId, parentFrameId, addHeight){
	var minHeight = 150;

	try{
		var strContentHeight = $("#" +contentId).css("height");
		var contentHeight = parseInt(strContentHeight.replace("px", "")) + parseInt(addHeight);

		if (contentHeight < minHeight){
			contentHeight = minHeight;
		}

		$("iframe[id=" + parentFrameId + "]", parent.document).css("height",contentHeight);
	
	}catch(e){
		alert(e);	////
	}
}


